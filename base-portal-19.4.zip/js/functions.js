function processCustomizations() {
    try {
        $.getJSON("/customization/customization.json", custData => {
            // There is a customziation file
            console.log(JSON.stringify(custData));

            $.each($("img.screenshot"), function(i, el) {
                if (el.src != null) {
                    var imageMapFile = '/customization/' + el.src.split('/')[el.src.split('/').length - 1].split('.')[0] + '.json';
                    try {
                        $.getJSON(imageMapFile, data => replaceImage(custData, data, el));
                    } catch (ex) {
                        console.log("There was an error:" + ex.message);
                    }
                } 
            });
        });
    } catch {
        console.log("No customization file at /customization.json");
    }
}

function replaceImage(custData, fieldData, originalImage) {
    // Use the source of the original image as the background of our canvas
    var background = new Image();
    background.src = originalImage.src;

    // Create the new canvas, and set the size equal to the image size
    var c = document.createElement('canvas');
    c.height = background.height;
    c.width = background.width;
    c.classList = originalImage.classList;

    // Get a 2D drawing context
    var ctx = c.getContext("2d");

    // Make sure the image is loaded first otherwise nothing will draw.
    background.onload = function() {
        // Draw the background image on the canvas
        ctx.drawImage(background,0,0);

        // For each field defined in the image customization json, put the sample text as defined in the customer customization file
        $.each (fieldData.fields, function (i, item) {
            if (custData.screenshot_sample_text[item.name] !== undefined) {
                ctx.font = fieldData.font;
                ctx.fillStyle = fieldData.color;
                ctx.fillText(custData.screenshot_sample_text[item.name], item.x, item.y);
            }
        });
    }

    // Replace the orignal image with our new pretty canvas
    originalImage.parentNode.replaceChild(c, originalImage);
}